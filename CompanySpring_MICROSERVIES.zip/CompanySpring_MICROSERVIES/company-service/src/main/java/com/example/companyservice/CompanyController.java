package com.example.companyservice;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/company")
@RestController
public class CompanyController {
    private List<Company> companies = Arrays.asList(
            new Company(1, "Joe Bloggs"),
            new Company(2, "Jane Doe"));
    
    @GetMapping
    public List<Company> getAllCustomers() {
        return companies;
    }
    
    @GetMapping("/{id}")
    public Company getCustomerById(@PathVariable int id) {
        return companies.stream()
                        .filter(company -> company.getId() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}