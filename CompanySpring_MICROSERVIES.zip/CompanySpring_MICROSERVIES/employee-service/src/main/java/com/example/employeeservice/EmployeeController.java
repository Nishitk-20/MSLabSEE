package com.example.employeeservice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Arrays;
import java.util.List;
@RequestMapping("/employee")
@RestController
public class EmployeeController {
    private final List<Employee> employees = Arrays.asList(
            new Employee(1, 1, "Product A"),
            new Employee(2, 1, "Product B"),
            new Employee(3, 2, "Product C"),
            new Employee(4, 1, "Product D"),
            new Employee(5, 2, "Product E"));

    @GetMapping
    public List<Employee> getAllOrders() {
        return employees;
    }

    @GetMapping("/{id}")
    public Employee getOrderById(@PathVariable int id) {
        return employees.stream()
                     .filter(employee -> employee.getId() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
}